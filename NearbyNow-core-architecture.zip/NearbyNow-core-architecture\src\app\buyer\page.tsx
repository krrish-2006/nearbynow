import { redirect } from "next/navigation";

export default function BuyerPage() {
  redirect("/");
}
